import UIKit

//using reduce, combining strings from an array to form a sentence.

let arrayOfStrings = ["Shivansh", "this", "side",".", "Hope", "you", "are", "doing", "well", "!"]

let finalSentence = arrayOfStrings.reduce("hey!") { result, word in
    return result.isEmpty ? word : result + " " + word
}

print(finalSentence)
//where "hey!" is the initial value to begin with and result is the cumulative result that is updated during each iteration. while, word is the current value/element in array
