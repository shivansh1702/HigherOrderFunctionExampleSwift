import UIKit

struct Product {
    let name: String
    let price: Double
    let isOnSale: Bool
    let discountPercent: Double
}

let products = [
    Product(name: "Laptop", price: 1000, isOnSale: true, discountPercent: 10),
    Product(name: "Phone", price: 500, isOnSale: false, discountPercent: 0),
    Product(name: "Tablet", price: 300, isOnSale: true, discountPercent: 20),
    Product(name: "Headphones", price: 150, isOnSale: true, discountPercent: 15)
]

//to find total price of discounted items

let totalPrice: Double = products.filter {
    $0.isOnSale
}.map { product in
    let discountedPrice = product.price - (product.price * product.discountPercent / 100)
    return discountedPrice
}.reduce(0) {
    $0 + $1
}

print(totalPrice)
