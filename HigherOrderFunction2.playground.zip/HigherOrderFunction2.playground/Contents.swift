import UIKit

let nestedArray = [[1,2,3], [4,5], [6,7], [8]]

let squaredNumbers = nestedArray.flatMap{$0} //flatten array to a single array
    .map{$0*$0} //squaring operation on each element

print(squaredNumbers)
